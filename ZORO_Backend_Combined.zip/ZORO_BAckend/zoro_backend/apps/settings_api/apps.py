from django.apps import AppConfig
class SettingsApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.settings_api'
