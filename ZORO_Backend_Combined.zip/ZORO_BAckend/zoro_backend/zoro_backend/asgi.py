import os
from django.core.asgi import get_asgi_application
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'zoro_backend.settings.production')
application = get_asgi_application()
